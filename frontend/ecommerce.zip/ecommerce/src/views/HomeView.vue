<script setup>
import Carousel from "../components/Carousel.vue";
import Category from "../components/Category.vue";
import Review from "../components/Review.vue";
</script>

<template>

    <Carousel />
    <Category />
    <Review />

</template>
