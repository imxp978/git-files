<script setup>
import Product from '../components/Product.vue'

</script>

<template>

  <Product />

</template>

<style>
</style>